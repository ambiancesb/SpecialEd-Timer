package com.roadrunner.specialedtimer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/*
Special Ed Timer is Copyrighted by Spencer Beaumier.

Special Ed Timer is distributed using the EULA License.
Reproduction is prohibited without creator permission.
Pirating this in any way is prohibited under penalty of law.
Changing or Redistributing the code is also prohibited.

Creator reserves the right to distribute licenses with the use of coupons.
Creator reserves the right to distribute this timber to faculty of the Washington County School District without a fee.

© Spencer Beaumier, All Rights Reserved

Special Ed Timer Version 0.5 Beta
*/

public class MainActivity extends AppCompatActivity {
    int hours = 0;
    int minutes = 0;
    int seconds = 0;

    // Create Text Views
    public TextView hoursDisplay;
    public TextView minutesDisplay;
    public TextView secondsDisplay;

    CountDownTimer eduTimer;
    long timerMilliseconds;
    boolean isRunning;
    MediaPlayer buzzer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        isRunning = false;

        hoursDisplay = (TextView) findViewById(R.id.hoursCounter);
        minutesDisplay = (TextView) findViewById(R.id.minutesCounter);
        secondsDisplay = (TextView) findViewById(R.id.secondsCounter);

        buzzer = MediaPlayer.create(this, R.raw.timerbell);

        updateDisplay();

    }

    // This function converts the inputed time into milliseconds for the countdown timer function.
    public void convertToMills(){
        timerMilliseconds = 0;
        timerMilliseconds += Long.valueOf(seconds * 1000);
        timerMilliseconds += Long.valueOf(minutes * 60000);
        timerMilliseconds += Long.valueOf(hours * 3600000);
    }

    public void resetTimer(View view) {

        if (isRunning) {
            eduTimer.cancel();
            isRunning = false;
        }

        // Set initial variables
        hours = 0;
        minutes = 0;
        seconds = 0;

        updateDisplay();
    }

    // This function controls the timer logic.
    public void startTimer(View view) {
        if (hours == 0 && minutes == 0 && seconds == 0) {
            Toast.makeText(this,"Please set a time.",Toast.LENGTH_SHORT).show();
        } else {
            if (isRunning == false) {
                convertToMills();
                isRunning = true;
                eduTimer = new CountDownTimer(timerMilliseconds, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        timerMilliseconds = millisUntilFinished;
                        updateCounter();
                    }

                    @Override
                    public void onFinish() {

                        buzzer.start();
                        isRunning = false;
                    }
                }.start();
            } else {
                Toast.makeText(this, "Timer Already Running", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void stopTimer(View view) {
        if (isRunning) {
            eduTimer.cancel();
            isRunning = false;
        }
    }

    // This function updates the timer display
    public void updateCounter(){
        // Logic to update timer value variables
        if (seconds == 0) {
            if (minutes == 0) {
                minutes = 59;
                seconds = 59;
                hours -= 1;
            } else {
                seconds = 59;
                minutes -=1;
            }

        } else {
            seconds -= 1;
        }

        // Call a Function to update the display
        updateDisplay();
    }

    public void updateDisplay() {
        String hoursStr = "";
        String minStr = "";
        String secStr = "";

        //format the numbers
        if (hours < 10) {
            hoursStr = "0" + Integer.toString(hours);
        }
        else {
            hoursStr = Integer.toString(hours);
        }

        if (minutes < 10) {
            minStr = "0" + Integer.toString(minutes);
        }
        else {
            minStr = Integer.toString(minutes);
        }

        if (seconds < 10) {
            secStr = "0" + Integer.toString(seconds);
        }
        else {
            secStr = Integer.toString(seconds);
        }

        hoursDisplay.setText(hoursStr);
        minutesDisplay.setText(minStr);
        secondsDisplay.setText(secStr);
    }

    public void randomHourTimer(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }

        minutes = new Random().nextInt((60) + 1);

        if (minutes == 60) {
            hours = 1;
            minutes = 0;
        }

        updateDisplay();
    }

    public void randomHalfHourTimer(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }

        minutes = new Random().nextInt((30) + 1);

        updateDisplay();
    }

    public void randomTenMinTimer(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }
        minutes = new Random().nextInt((10) + 1);

        updateDisplay();
    }

    public void randomFiveMinTimer(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }

        minutes = new Random().nextInt((5) + 1);

        updateDisplay();
    }

    public void addHour(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }

        hours += 1;
        updateDisplay();
    }

    public void addMin(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }

        minutes += 1;
        updateDisplay();
    }

    public void addSec(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }

        seconds += 1;
        updateDisplay();
    }

    public void subHour(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }

        hours -= 1;

        if (hours < 0){
            hours = 60;
        }

        updateDisplay();
    }

    public void subMin(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }

        minutes -= 1;

        if (minutes < 0){
            minutes = 60;
        }

        updateDisplay();
    }

    public void subSec(View view) {
        if (isRunning){
            eduTimer.cancel();
            isRunning = false;
        }

        seconds -= 1;

        if (seconds < 0){
            seconds = 60;
        }

        updateDisplay();
    }
}
